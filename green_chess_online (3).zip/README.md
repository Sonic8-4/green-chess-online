# Green Chess — online multiplayer starter

A responsive green-and-white chess website with real-time player matchmaking.

## Included
- Live matchmaking queue using Socket.IO
- Server-authoritative move validation using `chess.js`
- Responsive chessboard, move list, board flip, check/checkmate/draw status
- Guest display names; no account required in this starter
- Works in current Google Chrome and Safari on desktop and mobile

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run:
   ```bash
   npm install
   npm start
   ```
3. Open http://localhost:3000 in two separate browser windows/devices and press **Find a game** in each.

For a quick two-player test, both players must connect to the same running server.

## Publish it online
Deploy this folder to a Node.js hosting service that supports persistent WebSocket connections (for example Render, Railway, or a VPS).
- Build command: `npm install`
- Start command: `npm start`
- Set the service to use the provided `PORT` environment variable.
- Use the host's HTTPS URL. Socket.IO will use a secure WebSocket connection automatically.

## Google Search
The page includes a title, description, responsive layout and favicon. After deploying to your own domain:
1. Add the domain to Google Search Console and verify ownership.
2. Submit the site's URL for indexing.
3. Add a sitemap and privacy/terms pages before promoting the site.

## Important scope notes
This is a working multiplayer MVP foundation, not a production Chess.com replacement. It currently uses guest names and random matchmaking. It does not yet include persistent accounts, ratings, leaderboards, chat, clocks, anti-cheat systems, moderation, or a database. Add those features and production security controls before launching at scale.
