import { Chess } from "https://cdn.jsdelivr.net/npm/chess.js@1.4.0/+esm";

const socket = io();
const $ = (id) => document.getElementById(id);
const glyph = { wk:"♔", wq:"♕", wr:"♖", wb:"♗", wn:"♘", wp:"♙", bk:"♚", bq:"♛", br:"♜", bb:"♝", bn:"♞", bp:"♟" };
let chess = new Chess();
let myColor = null, gameActive = false, selected = null, legalTargets = [], flipped = false, lastMove = null;
let toastTimer;

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
function setStatus(title, description, icon="♙") {
  $("matchStatus").querySelector(".status-icon").textContent = icon;
  $("matchStatus").querySelector("strong").textContent = title;
  $("matchStatus").querySelector("p").textContent = description;
}
function pieceAt(square) { return chess.get(square); }
function squareName(file, rank) { return "abcdefgh"[file] + (8-rank); }

function renderBoard() {
  const board = $("board"); board.innerHTML = "";
  const ranks = flipped ? [1,2,3,4,5,6,7,8] : [8,7,6,5,4,3,2,1];
  const files = flipped ? ["h","g","f","e","d","c","b","a"] : ["a","b","c","d","e","f","g","h"];
  for (let ri=0;ri<8;ri++) for (let fi=0;fi<8;fi++) {
    const file = files[fi], rank = ranks[ri], sq = file+rank;
    const light = (files.indexOf(file) + (8-rank)) % 2 === 0;
    const el = document.createElement("button");
    el.type = "button"; el.className = "square " + (light ? "light" : "dark");
    el.setAttribute("aria-label", `${sq}${pieceAt(sq) ? " " + pieceAt(sq).color + " " + pieceAt(sq).type : ""}`);
    if (lastMove && (lastMove.from===sq || lastMove.to===sq)) el.classList.add("last-move");
    if (selected===sq) el.classList.add("selected");
    if (legalTargets.includes(sq)) el.classList.add(pieceAt(sq) ? "capture" : "target");
    const p = pieceAt(sq);
    if (p) {
      const span = document.createElement("span"); span.className = "piece " + (p.color==="w"?"white":"black");
      span.textContent = glyph[p.color+p.type]; el.appendChild(span);
    } else if (legalTargets.includes(sq)) {
      const dot = document.createElement("span"); dot.className = "dot"; el.appendChild(dot);
    }
    el.addEventListener("click", () => onSquare(sq));
    board.appendChild(el);
  }
  $("rankCoords").innerHTML = ranks.map(r=>`<span>${r}</span>`).join("");
  $("fileCoords").innerHTML = files.map(f=>`<span>${f}</span>`).join("");
}
function renderState() {
  renderBoard();
  const history = chess.history();
  $("moveCount").textContent = `${history.length} ${history.length===1?"move":"moves"}`;
  if (!history.length) $("moves").innerHTML = '<span class="empty-moves">Your moves will appear here.</span>';
  else {
    $("moves").innerHTML = "";
    for (let i=0;i<history.length;i+=2) {
      const chip = document.createElement("span"); chip.className="move-chip";
      const num = document.createElement("b"); num.textContent = `${Math.floor(i/2)+1}.`;
      chip.append(num, document.createTextNode(history[i] + (history[i+1] ? "  " + history[i+1] : "")));
      $("moves").appendChild(chip);
    }
    $("moves").scrollTop = $("moves").scrollHeight;
  }
  $("turnText").textContent = chess.turn()==="w" ? "White" : "Black";
  $("gameStatus").textContent = chess.isCheckmate() ? "Checkmate" : chess.isStalemate() ? "Stalemate" : chess.isDraw() ? "Draw" : chess.isCheck() ? "Check" : "In progress";
  if (chess.isGameOver()) {
    gameActive=false; $("resignBtn").disabled=true;
    if (chess.isCheckmate()) setStatus("Checkmate!", `${chess.turn()==="w"?"Black":"White"} wins.`, "♛");
    else setStatus("Game drawn", "This game has ended in a draw.", "½");
  }
}
function onSquare(sq) {
  if (!gameActive || chess.isGameOver()) return;
  if (chess.turn() !== (myColor==="white"?"w":"b")) { toast("It is your opponent’s turn."); return; }
  const p = pieceAt(sq);
  if (selected && legalTargets.includes(sq)) {
    const moving = pieceAt(selected);
    let promotion = "q";
    if (moving?.type==="p" && (sq.endsWith("8") || sq.endsWith("1"))) {
      const answer = (window.prompt("Promote to: queen (q), rook (r), bishop (b), or knight (n)?", "q") || "q").toLowerCase();
      promotion = ["q","r","b","n"].includes(answer) ? answer : "q";
    }
    socket.emit("make-move", {from:selected,to:sq,promotion});
    selected=null; legalTargets=[]; renderBoard(); return;
  }
  if (p && p.color===(myColor==="white"?"w":"b")) {
    selected=sq;
    legalTargets=chess.moves({square:sq,verbose:true}).map(m=>m.to);
  } else { selected=null; legalTargets=[]; }
  renderBoard();
}
function updateFromServer(state) {
  try {
    chess = new Chess();
    if (state.pgn) chess.loadPgn(state.pgn);
    else chess.load(state.fen);
  } catch(e) { console.error(e); return; }
  selected=null; legalTargets=[]; renderState();
}
function resetUI() {
  myColor=null; gameActive=false; chess=new Chess(); selected=null; legalTargets=[]; lastMove=null;
  $("yourColor").textContent="Not in a game"; $("opponentName").textContent="Waiting for opponent";
  $("opponentSub").textContent="Your next rival will appear here"; $("topPlayer").textContent="Black";
  $("bottomPlayer").textContent="White"; $("topYou").textContent=""; $("bottomYou").textContent="";
  $("findBtn").classList.remove("hidden"); $("findBtn").disabled=false;
  $("cancelBtn").classList.add("hidden"); $("resignBtn").disabled=true;
  renderState();
}

socket.on("connect", () => {
  $("connection").innerHTML="<i></i> Connected"; $("connection").classList.add("connected");
});
socket.on("disconnect", () => {
  $("connection").innerHTML="<i></i> Reconnecting"; $("connection").classList.remove("connected");
  gameActive=false; setStatus("Connection lost","Trying to reconnect to the game server.","!");
});
socket.on("queue-status", ({status}) => {
  if (status==="waiting") {
    $("findBtn").classList.add("hidden"); $("cancelBtn").classList.remove("hidden");
    setStatus("Finding an opponent","You’re in the queue. Keep this page open.","⌛");
  } else if (status==="idle") {
    $("findBtn").classList.remove("hidden"); $("cancelBtn").classList.add("hidden");
    setStatus("Ready to play?","Join the queue to find another player.");
  }
});
socket.on("game-start", ({color,opponent,state}) => {
  myColor=color; gameActive=true; flipped=color==="black"; lastMove=null;
  $("yourColor").textContent=color[0].toUpperCase()+color.slice(1);
  $("opponentName").textContent=opponent; $("opponentSub").textContent="Your opponent is ready";
  $("topPlayer").textContent= color==="white" ? opponent : $("playerName").value || "You";
  $("bottomPlayer").textContent= color==="white" ? $("playerName").value || "You" : opponent;
  $("topYou").textContent=color==="black"?"YOU":""; $("bottomYou").textContent=color==="white"?"YOU":"";
  $("findBtn").classList.add("hidden"); $("cancelBtn").classList.add("hidden"); $("resignBtn").disabled=false;
  setStatus("Opponent found!","You’re playing "+opponent+". Good luck!","♟");
  updateFromServer(state);
  renderBoard();
});
socket.on("game-state", (state) => {
  const oldHistory=chess.history();
  updateFromServer(state);
  const newHistory=chess.history();
  if (newHistory.length>oldHistory.length) {
    const m=chess.history({verbose:true}).slice(-1)[0];
    if (m) lastMove={from:m.from,to:m.to};
    renderBoard();
  }
  if (chess.isGameOver()) {
    if (chess.isCheckmate()) setStatus("Checkmate", `${chess.turn()==="w"?"Black":"White"} wins the game.`, "♛");
    else setStatus("Game drawn","The game has ended.","½");
  } else if (chess.isCheck()) setStatus("Check!","A king is under attack.","!");
  else setStatus(chess.turn()===(myColor==="white"?"w":"b")?"Your turn":"Opponent’s turn",
    chess.turn()===(myColor==="white"?"w":"b")?"Choose a piece to move.":"Waiting for your opponent’s move.","♟");
});
socket.on("move-rejected", ({message}) => toast(message || "Move rejected."));
socket.on("opponent-left", () => {
  gameActive=false; $("resignBtn").disabled=true; setStatus("Opponent disconnected","Your opponent left the game. Find a new game when you’re ready.","!");
  toast("Your opponent disconnected.");
});
socket.on("game-message", ({text}) => setStatus("Game finished",text,"♟"));
socket.on("game-finished", ({winner}) => {
  gameActive=false; $("resignBtn").disabled=true; $("gameStatus").textContent="Finished";
  setStatus("Game finished",winner ? winner+" wins by resignation." : "The game has ended.","♟");
});

$("findBtn").addEventListener("click", () => {
  if (!socket.connected) { toast("The server is reconnecting. Try again in a moment."); return; }
  socket.emit("find-game",{name:$("playerName").value.trim() || "Guest"});
});
$("cancelBtn").addEventListener("click", () => socket.emit("cancel-queue"));
$("resignBtn").addEventListener("click", () => {
  if (gameActive && window.confirm("Are you sure you want to resign?")) socket.emit("resign");
});
$("flipBtn").addEventListener("click", () => { flipped=!flipped; renderBoard(); });
$("soundBtn").addEventListener("click", () => toast("Sound effects are coming soon."));
renderState();
