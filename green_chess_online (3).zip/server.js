const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const { Chess } = require("chess.js");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true }));

let waitingPlayer = null;
const games = new Map();
const playerGame = new Map();

function publicState(game) {
  return {
    fen: game.chess.fen(),
    pgn: game.chess.pgn(),
    turn: game.chess.turn(),
    history: game.chess.history(),
    isGameOver: game.chess.isGameOver(),
    isCheck: game.chess.isCheck(),
    isCheckmate: game.chess.isCheckmate(),
    isDraw: game.chess.isDraw(),
    isStalemate: game.chess.isStalemate(),
    players: {
      white: game.names.white,
      black: game.names.black
    }
  };
}

function clearPlayerGame(socket) {
  const room = playerGame.get(socket.id);
  if (!room) return;
  const game = games.get(room);
  playerGame.delete(socket.id);
  if (game) {
    const other = game.white === socket.id ? game.black : game.white;
    if (other) io.to(other).emit("opponent-left");
    games.delete(room);
  }
}

function joinQueue(socket, rawName) {
  const name = String(rawName || "Guest").trim().slice(0, 18) || "Guest";

  if (waitingPlayer === socket.id) waitingPlayer = null;
  clearPlayerGame(socket);

  if (!waitingPlayer || waitingPlayer === socket.id || !io.sockets.sockets.has(waitingPlayer)) {
    waitingPlayer = socket.id;
    socket.emit("queue-status", { status: "waiting" });
    return;
  }

  const opponent = waitingPlayer;
  waitingPlayer = null;
  const room = crypto.randomUUID();
  const whiteSocket = Math.random() < 0.5 ? socket.id : opponent;
  const blackSocket = whiteSocket === socket.id ? opponent : socket.id;
  const whiteName = whiteSocket === socket.id ? name : (io.sockets.sockets.get(opponent)?.data.playerName || "Guest");
  const blackName = blackSocket === socket.id ? name : (io.sockets.sockets.get(opponent)?.data.playerName || "Guest");
  const game = {
    room, chess: new Chess(), white: whiteSocket, black: blackSocket,
    names: { white: whiteName, black: blackName }
  };
  games.set(room, game);
  playerGame.set(whiteSocket, room);
  playerGame.set(blackSocket, room);
  io.sockets.sockets.get(whiteSocket)?.join(room);
  io.sockets.sockets.get(blackSocket)?.join(room);

  for (const [id, color] of [[whiteSocket, "white"], [blackSocket, "black"]]) {
    io.to(id).emit("game-start", {
      room, color, opponent: color === "white" ? blackName : whiteName,
      state: publicState(game)
    });
  }
}

io.on("connection", (socket) => {
  socket.on("find-game", ({ name } = {}) => {
    socket.data.playerName = String(name || "Guest").trim().slice(0, 18) || "Guest";
    joinQueue(socket, socket.data.playerName);
  });

  socket.on("cancel-queue", () => {
    if (waitingPlayer === socket.id) waitingPlayer = null;
    socket.emit("queue-status", { status: "idle" });
  });

  socket.on("make-move", ({ from, to, promotion } = {}) => {
    const room = playerGame.get(socket.id);
    const game = room && games.get(room);
    if (!game || game.chess.isGameOver()) return;
    const color = game.white === socket.id ? "w" : game.black === socket.id ? "b" : null;
    if (!color || game.chess.turn() !== color) return;
    try {
      const move = game.chess.move({ from, to, promotion: promotion || "q" });
      if (!move) return;
      io.to(room).emit("game-state", publicState(game));
    } catch (_err) {
      socket.emit("move-rejected", { message: "That move is not legal. Try again." });
    }
  });

  socket.on("resign", () => {
    const room = playerGame.get(socket.id);
    const game = room && games.get(room);
    if (!game || game.chess.isGameOver()) return;
    const loser = game.white === socket.id ? "w" : "b";
    const winner = loser === "w" ? "Black" : "White";
    io.to(room).emit("game-message", { text: `${winner} wins by resignation.` });
    io.to(room).emit("game-finished", { reason: "resignation", winner });
    games.delete(room);
    playerGame.delete(game.white);
    playerGame.delete(game.black);
  });

  socket.on("disconnect", () => {
    if (waitingPlayer === socket.id) waitingPlayer = null;
    clearPlayerGame(socket);
  });
});

server.listen(PORT, () => console.log(`Green Chess is running on port ${PORT}`));
